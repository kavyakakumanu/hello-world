var swaggerUi = require('swagger-ui-express'),
    fs = require('fs');
const swaggerCombine = require('swagger-combine');

var express = require('express');

const app = express()

const testFolder = './jsons/';
var swaggerDocument = require('./swagger.json');


swaggerCombine('./swagger.json')
    .then((res) => {
        app.use('/api-docs/', swaggerUi.serve, swaggerUi.setup(res));
        app.listen(4000, () => console.log('Example app listening on port 4000!'))
    })
    .catch(err => console.error(err));






